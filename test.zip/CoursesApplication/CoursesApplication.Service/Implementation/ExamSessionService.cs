﻿using CoursesApplication.Domain.Models;
using CoursesApplication.Repository.Interface;
using CoursesApplication.Service.Interface;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoursesApplication.Service.Implementation
{
    public class ExamSessionService : IExamSessionService
    {
        private readonly IRepository<ExamSessionSignUp> _examSessionRepo;

        public ExamSessionService(IRepository<ExamSessionSignUp> examSessionRepo)
        {
            _examSessionRepo = examSessionRepo;
        }

        public ExamSessionSignUp GetExamSessionDetails(Guid id)
        {
            // TODO: Implement method
            return _examSessionRepo.Get(
                selector: x => x,
                predicate: x => x.Id == id,
                include: x => x.Include(y => y.DateCreated)
                                .Include(y => y.Owner));
        }
    }
}
