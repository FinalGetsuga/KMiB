﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoursesApplication.Domain.Models
{
    public class ExamSessionSignUp : BaseEntity
    {
        public Guid Id { get; set; }
        public string? OwnerId { get; set; }
        public CoursesApplicationUser? Owner { get; set; }
        public DateTime? DateCreated { get; set; }
    }
}
